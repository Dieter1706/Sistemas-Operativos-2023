#include <stdio.h>

int main(){
    int c1 = 4, c2 =3, h, A, p;
    h=c1*c1;
    printf("%d\n", h);
}